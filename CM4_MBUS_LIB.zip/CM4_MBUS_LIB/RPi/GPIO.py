BOARD = 1
OUT = 1
IN = 1
BCM=1
HIGH = 1
LOW =1

def setmode(a):
   pass
def setup(a, b):
   pass
def output(a, b):
   pass
def cleanup():
   pass
def setwarnings(flag):
   pass